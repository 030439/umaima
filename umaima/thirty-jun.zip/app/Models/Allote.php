<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Allote extends Model
{
    use HasFactory;
    protected $fillable = ['username', 'fullname','email','cellno','cnic'];
}
