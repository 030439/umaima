
<?php $breadCrumb='Reports / <span class="text-primary"> Ledger</span></i>'?>
<?php $__env->startSection('title', 'Ledger'); ?>
<?php $__env->startSection('content'); ?>

        <!-- / Navbar -->
        <!-- Content wrapper -->
        <div class="content-wrapper">
            <!-- Content -->
             
            <div class="container-xxl flex-grow-1 container-p-y">
                    
                    <!-- Product List Table -->
                    <div class="card">
                    <div class="card-header">
                        <div class="d-flex justify-content-between align-items-center row gap-6 gap-md-0">
                            <div class="col-md-2">
                                <select id="paymentType" class="form-select">
                                    <option value="">Filter By Payement Type</option>
                                    <option value="1">Received </option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <select id="subcat" class="form-select select2 text-capitalize">
                                </select>
                            </div>
                            <div class="col-md-2">
                                <select id="plotNumber" class="form-select select2 text-capitalize">
                                </select>
                            </div>
                            <div class="col-md-4">
                                <input type="text" class="form-control flatpickr-input" placeholder="YYYY-MM-DD to YYYY-MM-DD" id="flatpickr-range" readonly="readonly">
                            </div>
                        </div>
                    </div>
                </div>
                    <div class="card  mt-3">
                        
                        <div class="card-widget-separator-wrapper">
                            <div class="card-body card-widget-separator border-bottom">
                            <div class="row gy-4 gy-sm-1" id="allote-detail">
                            </div>
                        </div>
                        <div class="card-widget-separator-wrapper">
                            <div class="card-body card-widget-separator border-bottom">
                            <div class="row gy-4 gy-sm-1" id="allote-details">
                            </div>
                        </div>
                    </div>
                    <div class="card-datatable table-responsive">
                        <table class="datatables-products table dataTable no-footer dtr-column collapsed" id="DataTables_Table_0" aria-describedby="DataTables_Table_0_info" style="width: 958px;">
                            
                        </table>
                    </div>
            </div>
        </div>
    </div>
    <!-- / Content -->

          <?php $__env->stopSection(); ?> 
  

    
<?php $__env->startSection('files'); ?>

<!-- Core JS -->
<!-- build:js assets/vendor/js/core.js -->

<script src="../../assets/vendor/libs/jquery/jquery.js"></script>
<script src="../../assets/vendor/libs/popper/popper.js"></script>
<script src="../../assets/vendor/js/bootstrap.js"></script>
  <script src="../../assets/vendor/libs/node-waves/node-waves.js"></script>
<script src="../../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="../../assets/vendor/libs/hammer/hammer.js"></script>
<script src="../../assets/vendor/libs/i18n/i18n.js"></script>
<script src="../../assets/vendor/libs/typeahead-js/typeahead.js"></script>
<script src="../../assets/vendor/js/menu.js"></script>

<!-- endbuild -->

<!-- Vendors JS -->
<script src="../../assets/vendor/libs/moment/moment.js"></script>
<script src="../../assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js"></script>
<script src="../../assets/vendor/libs/select2/select2.js"></script>


<!-- Main JS -->

<script src="../../assets/vendor/libs/flatpickr/flatpickr.js"></script> 
<script src="../../assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js"></script>
<script src="../../assets/vendor/libs/bootstrap-daterangepicker/bootstrap-daterangepicker.js"></script>
<script src="../../assets/vendor/libs/jquery-timepicker/jquery-timepicker.js"></script>
<script src="../../assets/vendor/libs/pickr/pickr.js"></script>

<!-- Main JS -->



<!-- Page JS -->
<script src="../../assets/js/forms-pickers.js"></script>

<!-- Page JS -->
<script src="../../assets/js/ledger.js"></script>

<script src="../../assets/js/main.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\umaima\umaima\resources\views/reports/allote-ledger.blade.php ENDPATH**/ ?>