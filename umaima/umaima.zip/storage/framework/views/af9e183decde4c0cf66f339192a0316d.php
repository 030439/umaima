<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Schedule</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px 12px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .total-row {
            background-color: #f4f4f4;
            font-weight: bold;
        }
        .total-cell {
            text-align: right;
        }
    </style>
</head>
<body>

    <h1>Payment Schedule</h1>

    <table>
        <thead>
            <tr>
                <th>Payment Type</th>
                <th>Due Amount</th>
                <th>Due Date</th>
                <th>Amount Paid</th>
                <th>Paid On</th>
                <th>Outstanding</th>
                <th>Surcharge</th>
            </tr>
        </thead>
        <tbody>
            <!-- Loop through the payment schedules here -->
            <?php $__currentLoopData = $formattedSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($schedule['payment_type']); ?></td>
        <td><?php echo e($schedule['due_amount']); ?></td>
        <td><?php echo e($schedule['due_date']); ?></td>
        <td><?php echo e($schedule['amount_paid']); ?></td>
        <td><?php echo e($schedule['paid_on']); ?></td>
        <td><?php echo e($schedule['outstanding']); ?></td>
        <td><?php echo e($schedule['surcharge']); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
        <tfoot>
            <tr class="total-row">
                <td colspan="1" class="total-cell">Total</td>
                <td><?php echo e($totalDueAmount); ?></td>
                <td></td>
                <td><?php echo e($totalAmountPaid); ?></td>
                <td></td>
                <td><?php echo e($totalReceipts); ?></td>
                <td><?php echo e($totalOutstanding); ?></td>
                <td></td>
            </tr>
        </tfoot>
    </table>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\umaima\umaima\resources\views/payment_schedule.blade.php ENDPATH**/ ?>